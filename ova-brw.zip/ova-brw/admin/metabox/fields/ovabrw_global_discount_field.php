<tr class="row_discount">
    <td width="20%">
        <input 
        	type="text" 
        	class="input_text" 
        	placeholder="<?php esc_html_e('10', 'ova-brw'); ?>" 
        	name="ovabrw_gd_adult_price[]" 
        	autocomplete="off" />
    </td>
    <td width="20%">
        <input 
        	type="text" 
        	class="input_text" 
        	placeholder="<?php esc_html_e('10', 'ova-brw'); ?>" 
        	name="ovabrw_gd_children_price[]" 
        	autocomplete="off" />
    </td>
    <td width="20%">
        <input 
        	type="text" 
        	class="input_text" 
        	placeholder="<?php esc_html_e('10', 'ova-brw'); ?>" 
        	name="ovabrw_gd_baby_price[]" 
        	autocomplete="off" />
    </td>
    <td width="39%">
	    <input 
	    	type="text" 
	    	class="input_text ovabrw-global-duration short" 
	    	placeholder="<?php esc_html_e('1', 'ova-brw'); ?>" 
	    	name="ovabrw_gd_duration_min[]" 
	    	autocomplete="off" />
	    <input 
	    	type="text" 
	    	class="input_text ovabrw-global-duration short" 
	    	placeholder="<?php esc_html_e('2', 'ova-brw'); ?>" 
	    	name="ovabrw_gd_duration_max[]" 
	    	autocomplete="off" />
    </td>
    <td width="1%"><a href="#" class="button delete">x</a></td>
</tr>